<?php

require __DIR__ . '/vendor/autoload.php';
// Include common header
include 'inc/header.php';

// Include the routing logic
include 'router.php';


include 'inc/footer.php';